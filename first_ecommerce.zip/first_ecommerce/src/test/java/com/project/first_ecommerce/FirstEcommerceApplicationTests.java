package com.project.first_ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
