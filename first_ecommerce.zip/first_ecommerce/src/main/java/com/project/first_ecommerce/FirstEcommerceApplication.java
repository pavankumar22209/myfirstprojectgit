package com.project.first_ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstEcommerceApplication.class, args);
	}

}
